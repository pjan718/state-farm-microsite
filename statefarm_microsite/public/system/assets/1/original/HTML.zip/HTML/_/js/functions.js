// remap jQuery to $
(function($){

 





 



})(window.jQuery);
